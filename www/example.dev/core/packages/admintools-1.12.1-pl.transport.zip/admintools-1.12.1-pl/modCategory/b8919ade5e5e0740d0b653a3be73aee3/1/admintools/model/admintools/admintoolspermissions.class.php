<?php
/**
 * @package admintools
 */
class adminToolsPermissions extends xPDOSimpleObject {}