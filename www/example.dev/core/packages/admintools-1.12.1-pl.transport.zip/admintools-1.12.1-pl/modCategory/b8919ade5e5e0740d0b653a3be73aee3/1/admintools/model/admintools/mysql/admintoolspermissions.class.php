<?php
require_once (dirname(dirname(__FILE__)) . '/admintoolspermissions.class.php');
class adminToolsPermissions_mysql extends adminToolsPermissions {}