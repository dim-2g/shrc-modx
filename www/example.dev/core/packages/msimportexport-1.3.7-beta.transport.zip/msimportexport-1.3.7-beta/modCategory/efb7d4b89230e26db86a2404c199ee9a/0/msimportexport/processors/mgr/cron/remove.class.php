<?php
class msImportExportRemoveProcessor extends modObjectRemoveProcessor {
    public $languageTopics = array('msimportexport:default');
    public $classKey = 'MsieCron';
}
return 'msImportExportRemoveProcessor';