<?php
require_once (dirname(dirname(__FILE__)) . '/msiecron.class.php');
class MsieCron_mysql extends MsieCron {}