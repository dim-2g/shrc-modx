<?php
require_once (dirname(dirname(__FILE__)) . '/msiepresetsfields.class.php');
class MsiePresetsFields_mysql extends MsiePresetsFields {}