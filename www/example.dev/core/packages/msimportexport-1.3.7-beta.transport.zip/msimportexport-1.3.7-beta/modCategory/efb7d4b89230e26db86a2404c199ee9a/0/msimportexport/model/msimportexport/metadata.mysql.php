<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'MsieCron',
    1 => 'MsieHeadAlias',
    2 => 'MsiePresetsFields',
  ),
);