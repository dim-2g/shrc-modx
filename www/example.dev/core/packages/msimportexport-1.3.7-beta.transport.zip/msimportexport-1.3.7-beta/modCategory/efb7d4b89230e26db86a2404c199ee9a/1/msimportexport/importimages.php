<?php
define('MODX_API_MODE', true);
require_once dirname(dirname(dirname(dirname(__FILE__)))) . '/index.php';

$modx->getService('error', 'error.modError');
$modx->setLogLevel(modX::LOG_LEVEL_ERROR);
$modx->setLogTarget('FILE');

$groups = array('Administrator');
if (!$modx->user->isAuthenticated('mgr')) exit('Auth error');
if (!$modx->user->isMember($groups)) exit('Access error');
$ii = new ImportImage($modx);
$ii->import();


class ImportImage
{
    /* @var miniShop2 $miniShop2 */
    private $miniShop2 = null;
    /* @var ms2Gallery $ms2Gallery */
    private $ms2Gallery = null;

    /* @var modX $modx */
    private $modx = null;

    function __construct(modX &$modx, array $config = array())
    {
        $this->modx =& $modx;
        $this->config = array_merge(array(
            'pathImages' => MODX_ASSETS_PATH . 'code_1c/',
            'field' => 'code_1c',
        ), $config);
        set_time_limit($this->modx->getOption('msimportexport.time_limit', null, 600, true));
        if (!$this->miniShop2 = $this->modx->getService('miniShop2')) ;
        $this->miniShop2->initialize($this->modx->context->key);

        if (file_exists(MODX_CORE_PATH . 'components/ms2gallery')) {
            $this->ms2Gallery = $this->modx->getService('ms2gallery', 'ms2Gallery', MODX_CORE_PATH . 'components/ms2gallery/model/ms2gallery/');
        }

    }

    public function import()
    {
        $errors = 0;
        $success = 0;
        $images = glob($this->config['pathImages'] . '*.{jpg,jpeg,png,gif}', GLOB_BRACE);
        if ($images) {
            foreach ($images as $image) {
                $code = trim(mb_strtolower(basename($image, '.' . pathinfo($image, PATHINFO_EXTENSION))));
                if ($id = $this->getProductIdByCode($code, $this->config['field'])) {
                    if ($this->addImageGallery($image, $code, $id)) {
                        $success++;
                    } else {
                        $errors++;
                    }
                } else {
                    $errors++;
                    $this->modx->log(modX::LOG_LEVEL_ERROR, "[Import image] not find product by\n code: {$code}\n image: {$image}");
                }
            }
        }
        $this->modx->cacheManager->deleteTree($this->config['pathImages'], array('deleteTop' => false, 'skipDirs' => false, 'extensions' => array()));
        echo "Success: {$success}<br>";
        echo "Errors: {$errors}<br>";
    }


    /**
     * @param string $code
     * @param string $field
     * @param string $classKey
     * @return int
     */
    private function getProductIdByCode($code, $field = '', $classKey = 'msProductData')
    {
        $id = 0;
        $q = $this->modx->newQuery($classKey);
        $q->where(array($field => $code));
        $q->select('id');
        if ($q->prepare() && $q->stmt->execute()) {
            $id = $q->stmt->fetch(PDO::FETCH_COLUMN);
        }
        return $id;
    }

    /**
     * @param string $file
     * @param string $name
     * @param  int $resourceId
     * @return bool
     */
    private function addImageGallery($file, $name, $resourceId)
    {
        $success = true;
        //$processorsPath = $this->ms2Gallery ? $this->ms2Gallery->config['corePath'] . 'processors/mgr/' : MODX_CORE_PATH . 'components/minishop2/processors/mgr/';
        $processorsPath = MODX_CORE_PATH . 'components/minishop2/processors/mgr/';
        $response = $this->modx->runProcessor('gallery/upload',
            array('id' => $resourceId, 'name' => $name, 'file' => $file),
            array('processors_path' => $processorsPath)
        );
        if ($response->isError()) {
            $success = false;
            $this->modx->log(modX::LOG_LEVEL_ERROR, "[Import image] Error info: \n" . print_r($response->getAllErrors(), 1));
        }
        return $success;
    }
}

@session_write_close();