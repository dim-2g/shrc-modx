<?php
require_once (dirname(dirname(__FILE__)) . '/msorderlog.class.php');
class msOrderLog_mysql extends msOrderLog {}