<?php
require_once (dirname(dirname(__FILE__)) . '/msvendor.class.php');
class msVendor_mysql extends msVendor {}