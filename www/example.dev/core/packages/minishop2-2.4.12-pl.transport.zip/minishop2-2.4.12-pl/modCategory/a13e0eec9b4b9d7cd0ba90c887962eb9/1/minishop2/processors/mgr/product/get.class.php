<?php

class msProductGetProcessor extends modObjectGetProcessor
{
    public $classKey = 'msProduct';
    public $languageTopics = array('minishop2:default');

}

return 'msProductGetProcessor';